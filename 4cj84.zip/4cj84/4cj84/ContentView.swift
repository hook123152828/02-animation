import SwiftUI

struct Song: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let artist: String
    let albumArt: String
    let description: String
}

let a = """
愛情的大壞蛋
MV開場在酒吧
內向的修齊被一個陌生女生搭訕
看似有戲 卻好像是被調戲的戲
距離忽遠忽近 直到她頭靠在肩上
以為要到手時 一眨眼
女生就被別人叫車帶走了
修齊追上去 要阻止這一切
沒想到卻被女生比了個鬼臉
難道小丑是我自己 原來是我自作多情
於是修齊開始改變
變得外向 學會打扮 
開始用那個女生搭訕的方式
以為這樣能忘掉她
卻沒想到她又再次出現在自己面前
而且還帶上一個女的在自己面前舌吻
女生還不忘和修齊眼神交流
那眼神彷彿是在說「哈哈 羨慕吧」
於是修齊開始沈淪
覺得性能帶給他愉悅 讓他忘了這一切
但心裡朝朝暮暮的還是那個她
她開始受到很多異性喜歡
也玩弄了不少人感情 
成為名副其實的“愛情的大壞蛋”
但看到那個女生要被兩個男人帶走時
還是奮不顧身甩開身邊女人要搶走她
MV結尾停留兩人在車上
女生躺在修齊腿上 又對他比了一次鬼臉
把自己帶入進去 確實許多人就像修齊一樣
心裡有個永遠抹滅不掉的傷痕
或許每個“愛情的大壞蛋”
都曾天真的相信愛情
到頭來才發現
自己不玩別人 只有被別人玩的份
「就當作我是愛情的大壞蛋 不需要你原諒我」
或許我們不是缺愛 
我們只是需要找到能彌補傷痕的解藥
"""

let sampleSongs = [
    Song(title: "雨愛", artist: "楊丞琳", albumArt: "雨愛", description: "歌曲的創意是來自丞琳對於雨天戀愛存有許多的浪漫幻想，她總認為女生在雨天談戀愛比較可以有撒嬌的理由，而許多的美好回憶也都是在雨天發生，當然曾經令人心碎不已的失戀也總是在雨天，因此這首歌曲，就根據美好回憶，結合心痛記憶的複雜情緒而填寫出了，令人感動又心動的「雨愛」！"),
    Song(title: "愛情的大壞蛋", artist: "美秀集團", albumArt:"愛情的大壞蛋", description: a)
]

struct ContentView: View {
    var body: some View {
        TabView {
            SongsView()
                .tabItem {
                    Label("歌曲", systemImage: "music.note")
                }
            
            AboutView()
                .tabItem {
                    Label("關於", systemImage: "info.circle")
                }
        }
    }
}

struct SongsView: View {
    var body: some View {
        NavigationStack {
            List(sampleSongs) { song in
                NavigationLink(value: song) {
                    HStack {
                        Image(song.albumArt)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .cornerRadius(8)
                        VStack(alignment: .leading) {
                            Text(song.title)
                                .font(.headline)
                            Text(song.artist)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("愛情事故")
            .navigationDestination(for: Song.self) { song in
                SongDetailView(song: song)
            }
        }
    }
}

struct SongDetailView: View {
    let song: Song
    @State private var isRotating = false
    @State private var displayedText = ""
    @State private var currentIndex = 0

    var body: some View {
        VStack {
            Image(song.albumArt)
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .clipShape(Circle())
                .cornerRadius(10)
                .padding()
                .rotationEffect(.degrees(isRotating ? 360 : 0))
                .onAppear {
                    withAnimation(.linear(duration: 10).repeatForever(autoreverses: false)) {
                        isRotating = true
                    }
                    startTextAnimation()
                }

            Text(song.title)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top)

            Text(song.artist)
                .font(.title2)
                .foregroundColor(.secondary)
                .padding(.bottom)

            Text(displayedText)
                .font(.body)
                .padding()
                .onAppear {
                    startTextAnimation()
                }

            Spacer()
        }
        .navigationTitle(song.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    func startTextAnimation() {
        displayedText = ""
        currentIndex = 0
        Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
            if currentIndex < song.description.count {
                let index = song.description.index(song.description.startIndex, offsetBy: currentIndex)
                displayedText += String(song.description[index])
                currentIndex += 1
            } else {
                timer.invalidate()
            }
        }
    }
}

struct AboutView: View {
    var body: some View {
        VStack {
            Text("關於此應用程式")
                .font(.title)
                .padding()
            Text("這是一個愛情事故專用程式，展示了一些好聽的情歌，讓您可以瀏覽並欣賞每首歌曲由我精心挑選的歌曲。")
                .font(.body)
                .padding()
            Spacer()
        }
        .padding()
        .navigationTitle("關於")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
