//
//  _cj84App.swift
//  4cj84
//
//  Created by user17 on 2024/11/6.
//

import SwiftUI

@main
struct _cj84App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
